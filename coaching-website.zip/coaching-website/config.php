<?php
function db_connect() {
    $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }
    return $mysqli;
}
function e($str){ return htmlspecialchars($str,ENT_QUOTES,'UTF-8'); }
define('DB_HOST','localhost');
define('DB_NAME','results_db');
define('DB_USER','root');
define('DB_PASS','');
?>