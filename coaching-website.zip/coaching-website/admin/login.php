<?php
session_start(); require_once __DIR__.'/../config.php';
$mysqli=db_connect(); $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $username=$_POST['username']; $password=$_POST['password'];
 $stmt=$mysqli->prepare("SELECT id,password_hash FROM admins WHERE username=?");
 $stmt->bind_param('s',$username); $stmt->execute(); $stmt->bind_result($id,$hash);
 if($stmt->fetch() && password_verify($password,$hash)){
   $_SESSION['admin_id']=$id; header('Location: dashboard.php'); exit;
 } else { $error='Invalid login'; }
}
?>
<form method="post">
<input name="username" placeholder="Username" required>
<input type="password" name="password" placeholder="Password" required>
<button type="submit">Login</button>
<?php if($error) echo '<div>'.$error.'</div>'; ?>
</form>