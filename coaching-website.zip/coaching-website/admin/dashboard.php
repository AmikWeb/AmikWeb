<?php
session_start(); require_once __DIR__.'/../config.php';
if(!isset($_SESSION['admin_id'])){ header('Location: login.php'); exit; }
$mysqli=db_connect();
?>
<h2>Admin Dashboard</h2>
<a href="upload.php">Upload Results</a> | <a href="logout.php">Logout</a>
<?php
$res=$mysqli->query("SELECT id,roll_no,name,class,created_at FROM students ORDER BY created_at DESC LIMIT 10");
if($res->num_rows>0){
 echo '<table border=1><tr><th>Roll</th><th>Name</th><th>Class</th><th>Added</th></tr>';
 while($row=$res->fetch_assoc()){
   echo '<tr><td>'.e($row['roll_no']).'</td><td>'.e($row['name']).'</td><td>'.e($row['class']).'</td><td>'.e($row['created_at']).'</td></tr>';
 }
 echo '</table>';
}
?>