<?php
require_once __DIR__.'/../config.php';
$mysqli=db_connect();
$roll=$_GET['roll_no']??''; $name=$_GET['name']??''; $class=$_GET['class']??'';
$sql="SELECT s.roll_no,s.name,s.class,r.subject,r.marks,r.max_marks,r.term,r.year
 FROM students s JOIN results r ON s.id=r.student_id WHERE 1";
$params=[]; $types='';
if($roll){$sql.=" AND s.roll_no=?";$params[]=$roll;$types.='s';}
if($name){$sql.=" AND s.name LIKE ?";$params[]='%'.$name.'%';$types.='s';}
if($class){$sql.=" AND s.class=?";$params[]=$class;$types.='s';}
$stmt=$mysqli->prepare($sql);
if($params){$stmt->bind_param($types,...$params);} $stmt->execute();
$res=$stmt->get_result();
if($res->num_rows>0){
 echo '<table border=1><tr><th>Roll</th><th>Name</th><th>Class</th><th>Subject</th><th>Marks</th><th>Max</th><th>Term</th><th>Year</th></tr>';
 while($row=$res->fetch_assoc()){
  echo '<tr><td>'.e($row['roll_no']).'</td><td>'.e($row['name']).'</td><td>'.e($row['class']).'</td><td>'.e($row['subject']).'</td><td>'.e($row['marks']).'</td><td>'.e($row['max_marks']).'</td><td>'.e($row['term']).'</td><td>'.e($row['year']).'</td></tr>';
 }
 echo '</table>';
}else{ echo 'No results found'; }
?>