<?php ?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Result Search</title></head>
<body>
<h2>Search Student Results</h2>
<form id="searchForm">
  <input name="roll_no" placeholder="Roll No">
  <input name="name" placeholder="Name">
  <input name="class" placeholder="Class">
  <button type="submit">Search</button>
</form>
<div id="result"></div>
<script>
document.getElementById('searchForm').onsubmit=async e=>{
 e.preventDefault();
 let form=new FormData(e.target);
 let params=new URLSearchParams(form).toString();
 let res=await fetch('api/search_results.php?'+params);
 document.getElementById('result').innerHTML=await res.text();
};
</script>
</body>
</html>